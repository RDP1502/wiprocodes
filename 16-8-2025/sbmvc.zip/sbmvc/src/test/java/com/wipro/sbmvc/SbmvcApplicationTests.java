package com.wipro.sbmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbmvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
